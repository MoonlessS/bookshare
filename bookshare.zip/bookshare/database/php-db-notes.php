<?php
//  1. Query
    $query = "select * from cidade_v1";

  //	2. Estabelecimento da ligacao 'a bdd
    $conn = pg_connect("host=db.fe.up.pt dbname=jfaria user=jfaria password=jfaria");
    if (!$conn) {
      print "ERRO: Nao foi possivel estabelecer ligacao à base de dados";
      exit;
      }

  //	3. Execucao da query
    $result = pg_exec($conn, $query);

  //	4. Fecho da conexao 'a bdd
    pg_close($conn);

    //	5. Geração do html

			// 	5.1. Cabecalho da tabela
			echo "<table width=200 border=1>";
			echo "<tr align = center >";
				echo "<th>Cidade</th><th>Temperatura</th>";
			echo "</tr>";

			//	5.2. Linhas da tabela
			$num_linhas = pg_numrows($result);
			$i = 0;
			while ($i < $num_linhas) {

				$row = pg_fetch_row($result, $i);

				echo "<tr align = center >";
					echo "<td>".$row[0]."</td><td>".$row[1]."</td>";
				echo "</tr>";

			$i++;
			}

			//	5.3. Fecho da tabela
			echo "</table>";


//	Alternativa 1 - fetch_row: acesso aos dados pelo indice numérico das colunas)

      $row = pg_fetch_row($result, 0); //obter a primeira linha [0]
				$cidade = $row[0];  			 //obter a primeira coluna [0] da linha selecionada
				$temperatura = $row[1];			 //obter a segunda coluna [1] da linha selecionada

//  Alternativa 2 - fetch_assoc: acesso aos pelos nomes das colunas
        $row = pg_fetch_assoc($result);
				$cidade = $row["nome"];
				$temperatura = $row["temperatura"];

 ?>

 <?php

		$num_linhas = pg_numrows($result);
		$i = 0;
		while ($i < $num_linhas) {
			$row = pg_fetch_row($result, $i);
			echo "<input type=\"radio\" name=\"id_cidade\" value=".$row[0].">Cidade ".$row[1]."</input>";
			$i++;
			}
		?>

  <form method="POST" action="displayTemperaturas-v5.php">

		<?php

		$row = pg_fetch_assoc($result);
		while (isset($row["id"])) {
			echo "<input type=\"radio\" name=\"id_cidade\" value=".$row["id"].">Cidade ".$row["nome"]."</input>";
			$row = pg_fetch_assoc($result);
			}
		?>

		<br><br>
		<input type="submit" value="Submeter" name="botao1">

	</form>

<?php
  //query na tabela cidade do schema demosgdb
echo "query na tabelas cidades do schema demosgdb<br>";

$query = "set schema 'demosgbd';";
pg_exec($conn, $query);

$query = "select * from cidade;";
$result = pg_exec($conn, $query);

$num_linhas = pg_numrows($result);
$i = 0;
while ($i < $num_linhas) {
	$row = pg_fetch_row($result, $i);
	echo "<tr>";
		echo "<td>".$row[0]."</td><td>".$row[1]."</td>";
	echo "</tr>";
	$i++;
}
echo "</table><br><br>";

//query na tabela cidade_v1 do schema public
echo "query na tabela cidade do schema public<br>";

$query = "set schema 'public';";
pg_exec($conn, $query);

$query = "select * from cidade_v1;";
$result = pg_exec($conn, $query);

$num_linhas = pg_numrows($result);
$i = 0;
while ($i < $num_linhas) {
	$row = pg_fetch_row($result, $i);
	echo "<tr>";
		echo "<td>".$row[0]."</td><td>".$row[1]."</td>";
	echo "</tr>";
	$i++;
}
echo "</table>";



//Alternativa 2 - fetch_assoc (notar que, neste caso, o indice do registo da instruçõo de fetch é incrementado automaticamente)

$num_linhas = pg_numrows($result);
$i = 0;
while ($i < $num_linhas) {

	$row = pg_fetch_assoc($result);

	echo "<tr>";
		echo "<td>".$row["cidade"]."</td><td>".$row["valor"]."</td>";
	echo "</tr>";

	$i++;
}



$num_linhas = pg_numrows($result);


	$i = 0;
	while ($i < $num_linhas)
		{
		$row = pg_fetch_row($result, $i);
			echo "<Option value=".$row[2].">".$row[0]."</Option><p>";
		$i++;
		}


	echo "</Select><p>";


//Alterar a base de dados

  $query = "update temperaturas set valor=".$_POST['nova_temperatura']." where cidade='".$_GET['cidade']."';";

  echo "Query = ".$query."<p>";

  /*Execucao da query */
  $result = pg_exec($conn, $query);




?>
