SELECT
 *
FROM
 pg_catalog.pg_tables
WHERE
 schemaname = 'bookshare'
