<?php  set_include_path( get_include_path() . PATH_SEPARATOR .                  "/usr/users2/mieec2013/up201307839/public_html/trabalhosSiem/trabalhoPHP-1/bookshare/" . PATH_SEPARATOR .                  "/usr/users2/mieec2013/up201305298/public_html/trabalhosSiem/trabalhoPHP-1/bookshare/" . PATH_SEPARATOR .                  "/srv/www/htdocs/bookshare/bookshare/"                 ); ?>
<?php $pageTitle = null;$pageType = null; $contentID= null; ?>
<?php include_once("template/templateTop.php");?>
    <article class="main">
<!-- /////////////////////////////////////////////////////////////////////// -->
    <div class="book-title-container">
        <div id="title" width=40%>Demon God Trafford</div>
        <div id="author" width=40%>By: Ghost Writer</div>
        <div id="stars" width=10%>*****</div>
    </div>
    <div>
        <div class="title black">Chapter 2 - First Yuan Heavy Water</div>
        <div class="black description">
          <p dir="ltr">He could see that around the area where the bead broke, there was a glob of black mist.</p>
          <p dir="ltr">The black mist seemed quite wet and it only covered an area of about one square foot. In addition, it seemed as if it wouldn’t disperse.&nbsp;</p>
          <p dir="ltr">Seeing this, Liu Ming was intrigued. He suddenly waved his sleeves and a wild gust came rushing out and went straight to the black mist.&nbsp;</p>
          <p dir="ltr">With a “pu”, the wild wind ended up going to the left and right of the black mist without blowing the mist at all.</p>
          <p dir="ltr">With this, Liu Ming was intrigued. He raised his hand and a fire ball flew out.</p>
          <p dir="ltr">In the end, with a muffled sound, the moment that the fireball touched the black mist, it was extinguished immediately.</p>
          <p dir="ltr">Seeing this, Liu Ming’s face became curious.&nbsp;</p>
          <p dir="ltr">He paused for a moment before his sleeve shook. With a ding sound, a silver chain shot out from his sleeve and was aimed towards the black mist.</p>
          <p dir="ltr">“Peng!”</p>
          <p dir="ltr">The front part of the silver chain barely stuck into the black mist before it was stopped by some strange force.</p>
          <p dir="ltr">Right when Liu Ming winced his eyes and was about to use more force when the strange force disappeared.</p>
          <p dir="ltr">The silver chain cut through the mist and the inside of it was completely empty without anything within.</p>
          <p dir="ltr">Liu Ming’s wrist flicked and pulled back the silver chain before he was about to go closer to look at the mist.</p>
          <p dir="ltr">However, at this time, the black mist bubbled as it disappeared at an alarming speed. In the blink of an eye, the mist disappeared and the ground where the mist of was left with a large hole.&nbsp;</p>
          <p dir="ltr">Seeing this, Liu Ming thought about the large noise from before and thoughtfully walked up. His eyes made a glint as he looked into the hole and a strange expression appeared on his face.</p>
          <p dir="ltr">“What is this, it looks quite strange!”</p>
          <p dir="ltr">Liu Ming muttered as his arm raised up and five fingers on a single hand spread out as his hand pointed to the bottom of the hole.</p>
          <p dir="ltr">He used a hand technique and suddenly, a black mist swirled out and followed his arm to form a black tentacle. Then, the tentacle went deep into the hole.</p>
          <p dir="ltr">Then, his wrist flicked and the black tentacle suddenly pulled back. It seemed as if he was about to pull something out of the hole.</p>
          <p dir="ltr">However, even though the black tentacle became as straight as a pencil and tightened, the thing within the hole stayed solidly at the bottom of the large hole without moving at all.</p>
          <p dir="ltr">Liu MIng saw this scene and he frowned. His arm suddenly moved and an invisible strength followed the tentacle down. Then, his five fingers slightly curled.</p>
          <p dir="ltr">A strength that was many times larger than before pulled up.</p>
          <p dir="ltr">“Hong!”</p>
          <p dir="ltr">With Liu Ming’s strength, the rock ground under his feet became shattered. However, the object within the hole stayed firm.</p>
          <p dir="ltr">With this, Liu Ming’s face truly changed.</p>
          <p dir="ltr">The amount of strength that he used was enough to easily pick up an object of at least a couple hundred pounds. However, even that couldn’t touch the object below.&nbsp;</p>
          <p dir="ltr">This would mean that the object was over a thousand pounds.&nbsp;</p>
          <p dir="ltr">It was no wonder that as soon as this object rolled out of the bead, it immediately crushed the ground and sunk so deep.&nbsp;</p>
          <p dir="ltr">Liu Ming’s mind thought like that and did not try to underestimate the object. He first made a couple of techniques to add quite a few techniques to himself. Then, he extended his other arm.&nbsp;</p>
          <p dir="ltr">The black tentacle suddenly retracted back within Liu Ming and ding dang sounds rang in Liu Min’s sleeve. The silver chain shot out and entered within the hole.</p>
          <p dir="ltr">A large sound appeared.</p>
          <p dir="ltr">Liu Ming’s two hands shook as he grabbed onto the silver chain and pulled.</p>
          <p dir="ltr">“Hong long long!”</p>
          <p dir="ltr">An incredible aura exploded from Liu Ming!</p>
          <p dir="ltr">The secret room shook slightly and the object within the hole was slowly pulled up.</p>
          <p dir="ltr">However, his two arms were bulging with exerted muscle while a green vein was popping on his forehead. It was obvious that he was using a lot of strength.&nbsp;</p>
          <p dir="ltr">Moments later, as Liu Ming kept pulling up with both hands, he finally pulled out the other end of the silver chain from the hole. At the end of the chain was a ball of black light that was stuck to the chain.</p>
          <p dir="ltr">At the middle of the light ball was a drop of jet black liquid that was the size of a bean. In addition, there were a couple wisps of black air near this liquid.</p>
          <p dir="ltr">Liu Ming did not dare underestimate the black liquid. With a shake of his sleeve, a light silver small cauldron flew out and with a blur, it was a couple feet tall and landed solidly under the black liquid.</p>
          <p dir="ltr">Then, he made a single handed techniques and the formation flags flashed a couple of times before a light cover that was around the room disappeared into the ground with a flash.</p>
          <p dir="ltr">The originally normal stone ground started to shine a crystal hue.&nbsp;</p>
          <p dir="ltr">At this time, Liu Ming stopped his Fa Li.</p>
          <p dir="ltr">The black liquid on the end of the chain gave a blur and dropped down accurately into the cauldron.</p>
          <p dir="ltr">Then, in the next moment, a large sound resonated!</p>
          <p dir="ltr">The cauldron gave quite a few flashes as it shook crazily. The three foots of the cauldron sunk over half a feet into the ground amidst the shaking.</p>
          <p dir="ltr">This scene made Liu Ming speechless.&nbsp;</p>
          <p dir="ltr">This was after he had used the formation to strengthen the secret room’s ground.</p>
          <p dir="ltr">Otherwise, the cauldron might have been like before and sunk into the ground without sight.</p>
          <p dir="ltr">However, this was to be expected!</p>
          <p dir="ltr">Liu Ming had used all of his strength and could barely raise the black liquid. It was estimated to be at least three to four thousand pounds. Otherwise, it wouldn’t have appeared so incredible.&nbsp;</p>
          <p dir="ltr">Without question, this thing was an impressive treasure.</p>
          <p dir="ltr">Liu Ming thought quickly and did not remember hearing anything about this.&nbsp;</p>
          <p dir="ltr">However, now that he had extra time, he could slowly research the liquid.&nbsp;</p>
          <p dir="ltr">Liu Ming put away the silver chain and came close to the cauldron to peer at the black liquid.</p>
          <p dir="ltr">…..</p>
          <p dir="ltr">At the same time, from an island far away, within a large hall over two hundred feet hall, a Sea Race elder in purple robes had a face full of fury while he was criticizing a white armored guard before him:</p>
          <p dir="ltr">“Useless! A bunch of useless people! How can you guys let a guard of the treasure warehouse take away my First Yuan Heavy Water that I’ve spent over a hundred years agglomerating. Do you know that without the First Yuan Heavy Water, my item will lose over half of its power. Has anything else been lost in the warehouse?”</p>
          <p dir="ltr">“Elder please calm down! Besides this First Yuan Heavy Water, no other treasure within the warehouse has been lost. In addition, we have found out the guard who has stolen the First Yuan Heavy Water and has left our clan not long ago to go to the human race in Da Xuan Country to protect the Thirteenth Princess.” The white armored Sea Race guard was an incredibly sturdy build young male and was currently drenched in sweat as he replied.</p>
          <p dir="ltr">“Going to protect the thirteenth. Hmph, looks like she has been planning this for a while otherwise how could there be something so coincidental. If it weren’t for the fact that the First Yuan Heavy Water was so special and naturally could not trigger the warnings for the warehouse. Otherwise, it wouldn’t only be this missing. Immediately send someone to give word to the thirteenth and immediately have her arrest the guard that stole this treasure before she sends this thief back immediately.” The purple robed elder gave a cold hmph and said with more anger on his face.&nbsp;</p>
          <p dir="ltr">“Yes, I will give word to the thirteenth! That’s right, Clan Leader gave word a while ago to have elder go over and discuss something with the other two clans.” The guard quickly replied before saying something else hastily.</p>
          <p dir="ltr">‘The other two clans have sent people over again. With their increase in communication frequency, it seems like it’s quite close to something large happening.” The purple robed Sea Race elder heard this news and calmed down before thinking thoughtfully.</p>
          <p dir="ltr">Not long after, a white light rushed up from the giant island. With a couple of flashes, it disappeared into the sky.</p>
          <p dir="ltr">…..</p>
          <p dir="ltr">Liu Ming sighed and with a flick of his wrist, he put away his Cyan Moon Sword in his hands.</p>
          <p dir="ltr">In the past hour, he had used various methods to test the black liquid. In the end, not only did he find that the object was incredibly heavy and emanated a thick water attributed energy. In addition, within it seemed to have a scary amount of compressed energy.</p>
          <p dir="ltr">Although he didn’t know what energy this was, the amount of power behind this was incredible. If it was released, it was enough to blow a small portion of the Immortal Dawn Mountain flat.&nbsp;</p>
          <p dir="ltr">And when sharp knives cut into the black liquid, it could not go anywhere within it and would be bounced away by the energy.</p>
          <p dir="ltr">In addition, this thing had incredible effects that could push away fire and split water.</p>
          <p dir="ltr">As soon as fire was about half a feet away the black liquid, it would be affected and disperse. As for the clear water, as soon as it neared the black liquid, it would turn into mist and go around the black liquid.</p>
          <p dir="ltr">The mysterious points of this thing was the most incredible that Liu Ming saw in his entire life!</p>
          <p dir="ltr">Although he didn’t know the origin of this object, since he found it on a member of the Sea Race, it was most likely related somewhat to the Sea Race and he couldn’t just display it and ask others.</p>
          <p dir="ltr">When he finished the matter with the Sea Race, he could go to the market to read up on books regarding Spirit items and strange treasures to see if he could find any related resources.</p>
          <p dir="ltr">Thinking of this, Liu Ming’s hand flipped and a conch that was the size of a fist appeared in his hand.&nbsp;</p>
          <p dir="ltr">As he waved the conch before him, a ray of color shot out and the cauldron along with the black liquid that within disappeared without a trace.</p>
          <p dir="ltr">Liu Ming then slightly sighed.</p>
          <p dir="ltr">Thankfully he had the Sumeru Conch which would disregard the weight of an object when placed within. Otherwise, although normal Storage Glyphs would be able to collect this liquid, with its incredible weight, Liu Ming would not be able to carry it around with him.</p>
          <p dir="ltr">If that was the case, it would be quite troublesome to keep it safe.</p>
          <p dir="ltr">In the remaining time, he took out the small blue flag and started to slowly refine and understand this Middle Tier Totem.&nbsp;</p>
          <p dir="ltr">In the morning of the second day, Liu Ming left the cave soundlessly. In addition, he became disguised as an indistinguishable middle aged man and immediately went down the mountain.</p>
          <p dir="ltr">When night came, he returned his original appearance and returned how his cave. Walking in, he saw Qian Ruping and Hu Chunniang closely talking together.</p>
          <p dir="ltr">This made Liu Ming pause for a while.</p>
          <p dir="ltr">Qian Ruping had been extremely wary of strangers due to her experience in younger years. However, Hu Chunniang was really impressive in being able to be this close with Qian Ruping in just half a day.</p>

          <div class="title black float"><a href="ongoing-books-list/demon-god-trafford/chapter1.php">Previous Chapter</a></div>
          <div class="title black float-right"><a href="ongoing-books-list/demon-god-trafford/chapter3.php">Next Chapter</a></div>
        </div>
      </div>
<!-- /////////////////////////////////////////////////////////////////////// -->
    </article>
  <?php include_once("apresentacao/sidebar.php"); display_sidebar(); ?>
<?php include_once("template/templateBot.php"); ?>
